# ReStart90 - Riri Agent Integration Handoff for Anis

## Goal before submission

Make the existing Riri conversation use a real server-side model for ordinary conversation and emotional support, while keeping all medical, red-flag, task-state and record-writing decisions inside the existing deterministic rules.

Do not redesign the website and do not replace the medical engine. The full UI, three roles, 90-day map, records, film section and Riri drawer already exist.

## What is already implemented

- Frontend chat UI: `public/app.js`
- Riri conversation and medical boundary: `lib/riri.js`
- Server-only DeepSeek adapter: `lib/model-provider.js`
- API route: `POST /api/patients/:id/agent` in `server.js`
- Provider and safety tests: `test/riri.test.js`
- Environment template: `.env.example`

The provider is deliberately called only for ordinary conversation and emotions. Medical questions, red flags, confirmed orders, product/provider status, record-writing actions and paused tasks stay rule-based.

## Required integration work

1. Create or use one GitHub repository named `ReStart90` and commit this complete source tree. Do not upload the ZIP itself as the website.
2. Deploy the repository with Node.js 22.13 or newer.
3. Configure secrets only in the deployment platform:

```text
MODEL_PROVIDER=deepseek
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-chat
DEEPSEEK_API_KEY=<server secret>
```

4. Never place the API key in `public/`, browser JavaScript, GitHub, screenshots or logs.
5. Run `npm ci` and `npm test`. Submission gate: all 113 tests pass.
6. Confirm the production server log reports `Riri: DeepSeek configured, connects on request`.
7. Verify these acceptance cases on the deployed website:
   - Ordinary message: Riri returns a natural bilingual answer and the UI label shows AI mode.
   - Emotion message: Riri responds warmly without inventing records or treatment.
   - Medication, wound, weight-bearing or exercise-order question: Riri refuses to diagnose or change orders.
   - Red-flag wording: deterministic rules respond before any model call and show escalation guidance.
   - No key / provider timeout / provider error: the existing offline reply still works.
   - Chatting never marks a task complete; saving a note still requires explicit confirmation.

## Files that must not be weakened

- `lib/engine.js`: task progression, red flags, safety pauses and summaries
- `lib/riri.js`: clinical refusal, context minimization, action confirmation and response validation
- `lib/durable.js`: account and private-chat isolation
- `server.js`: authorization, CSRF and role checks

## Data boundary

Only the reduced `patient_context` assembled in `lib/riri.js` may be sent to the model. Do not send identities, uploaded PDFs, complete charts, private notes, credentials or database contents.

## Competition handoff

After the API works, push the final commit and send Ashley:

- public GitHub repository URL;
- deployed website URL;
- final commit SHA;
- screenshot or short recording showing one normal Riri reply and one medical refusal;
- confirmation that `npm test` passed.

For this deadline, finish and verify the existing DeepSeek path first. Multi-model routing for GPT can be added later without changing the Riri safety boundary.
